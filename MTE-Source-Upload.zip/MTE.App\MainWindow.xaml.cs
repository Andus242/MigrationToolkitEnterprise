﻿using System.Windows;
using MTE.App.ViewModels;

namespace MTE.App;

public partial class MainWindow : Window
{
    public MainWindow(MainViewModel viewModel)
    {
        InitializeComponent();

        DataContext = viewModel;
    }
}
