﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using MTE.Core.Models;

namespace MTE.App.ViewModels;

public sealed class SelectableUserProfile : INotifyPropertyChanged
{
    private bool _isSelected;

    private string _copyMode = "Whole Profile";

    private bool _copyDesktop = true;
    private bool _copyDocuments = true;
    private bool _copyDownloads = true;
    private bool _copyPictures = true;
    private bool _copyMusic = true;
    private bool _copyVideos = true;
    private bool _copyFavorites = true;

    public SelectableUserProfile(
        UserProfileInformation profile,
        bool isSelected = false)
    {
        Profile = profile;
        _isSelected = isSelected;
    }

    public UserProfileInformation Profile { get; private set; }

    public string UserName =>
        Profile.UserName;

    public string ProfilePath =>
        Profile.ProfilePath;

    public long SizeBytes =>
        Profile.SizeBytes;

    public string SizeDisplay
    {
        get
        {
            const double mb = 1024d * 1024d;
            const double gb = mb * 1024d;

            if (SizeBytes >= gb)
                return $"{SizeBytes / gb:N1} GB";

            if (SizeBytes >= mb)
                return $"{SizeBytes / mb:N1} MB";

            if (SizeBytes >= 1024)
                return $"{SizeBytes / 1024d:N1} KB";

            return $"{SizeBytes:N0} bytes";
        }
    }

    public bool IsCurrentUser =>
        Profile.IsCurrentUser;

    public bool IsSystemProfile =>
        Profile.IsSystemProfile;

    public bool IsSelected
    {
        get => _isSelected;
        set
        {
            if (_isSelected == value)
                return;

            _isSelected = value;
            OnPropertyChanged();

            SelectionChanged?.Invoke(this, EventArgs.Empty);
        }
    }

    public string CopyMode
    {
        get => _copyMode;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                return;

            if (_copyMode == value)
                return;

            _copyMode = value;

            OnPropertyChanged();
            OnPropertyChanged(nameof(CopyWholeProfile));
            OnPropertyChanged(nameof(FolderSelectionEnabled));
            OnPropertyChanged(nameof(SelectedFoldersDisplay));
        }
    }

    public bool CopyWholeProfile =>
        string.Equals(
            CopyMode,
            "Whole Profile",
            StringComparison.OrdinalIgnoreCase);

    public bool FolderSelectionEnabled =>
        !CopyWholeProfile;

    public bool CopyDesktop
    {
        get => _copyDesktop;
        set
        {
            if (_copyDesktop == value)
                return;

            _copyDesktop = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(SelectedFoldersDisplay));
        }
    }

    public bool CopyDocuments
    {
        get => _copyDocuments;
        set
        {
            if (_copyDocuments == value)
                return;

            _copyDocuments = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(SelectedFoldersDisplay));
        }
    }

    public bool CopyDownloads
    {
        get => _copyDownloads;
        set
        {
            if (_copyDownloads == value)
                return;

            _copyDownloads = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(SelectedFoldersDisplay));
        }
    }

    public bool CopyPictures
    {
        get => _copyPictures;
        set
        {
            if (_copyPictures == value)
                return;

            _copyPictures = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(SelectedFoldersDisplay));
        }
    }

    public bool CopyMusic
    {
        get => _copyMusic;
        set
        {
            if (_copyMusic == value)
                return;

            _copyMusic = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(SelectedFoldersDisplay));
        }
    }

    public bool CopyVideos
    {
        get => _copyVideos;
        set
        {
            if (_copyVideos == value)
                return;

            _copyVideos = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(SelectedFoldersDisplay));
        }
    }

    public bool CopyFavorites
    {
        get => _copyFavorites;
        set
        {
            if (_copyFavorites == value)
                return;

            _copyFavorites = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(SelectedFoldersDisplay));
        }
    }

    public IReadOnlyList<string>? SelectedFolders
    {
        get
        {
            if (CopyWholeProfile)
                return null;

            var folders = new List<string>();

            if (CopyDesktop)
                folders.Add("Desktop");

            if (CopyDocuments)
                folders.Add("Documents");

            if (CopyDownloads)
                folders.Add("Downloads");

            if (CopyPictures)
                folders.Add("Pictures");

            if (CopyMusic)
                folders.Add("Music");

            if (CopyVideos)
                folders.Add("Videos");

            if (CopyFavorites)
                folders.Add("Favorites");

            return folders;
        }
    }

    public string SelectedFoldersDisplay
    {
        get
        {
            if (CopyWholeProfile)
                return "Entire profile";

            var folders = SelectedFolders;

            if (folders is null)
                return "Entire profile";

            if (folders.Count == 0)
                return "No folders selected";

            return string.Join(", ", folders);
        }
    }

    public event EventHandler? SelectionChanged;

    public event PropertyChangedEventHandler? PropertyChanged;

    public void UpdateSize(long sizeBytes)
    {
        Profile = new UserProfileInformation
        {
            UserName = Profile.UserName,
            ProfilePath = Profile.ProfilePath,
            SizeBytes = sizeBytes,
            IsCurrentUser = Profile.IsCurrentUser,
            IsSystemProfile = Profile.IsSystemProfile,
            DiscoveredAt = Profile.DiscoveredAt
        };

        OnPropertyChanged(nameof(SizeBytes));
        OnPropertyChanged(nameof(SizeDisplay));
    }

    private void OnPropertyChanged(
        [CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(
            this,
            new PropertyChangedEventArgs(propertyName));
    }
}


